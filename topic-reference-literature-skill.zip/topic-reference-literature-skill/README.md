# Topic Reference Literature Skill

一个面向科研选题的 Codex skill：给出课题方向后，自动完成真实文献检索、元数据核验、强制补全影响因子和 JCR 分区，并生成可直接用于开题、基金、论文设计的 Word 参考文献汇总表。

## 为什么实用

科研早期最耗时间的工作，往往不是“找几篇文章”，而是把文献变成一个能支撑课题设计的证据包。这个 skill 把这件事标准化：

- 按课题拆分疾病背景、机制、材料/方法、干预证据和评价指标。
- 真实检索 PubMed、CrossRef、出版社页面和公开 JCR/期刊指标来源。
- 默认筛选不少于 20 篇高质量文献。
- 强制填写 `JCR 年份 + Journal Impact Factor + JCR 分区`。
- 不能整列用“待核实”糊弄；生成脚本会拦截缺失指标。
- 自动生成中文 Word 表格，包含每篇文献对课题的具体用途。

## 适合谁

- 准备开题、基金标书、研究方案的研究生和科研人员。
- 需要快速搭建某一方向参考文献库的医生、PI、实验室成员。
- 经常需要把“一个想法”变成“可写进方案的文献证据链”的人。

## 输出内容

运行后会在课题目录下生成：

```text
<topic-root>/01_Literature/
├── references.json
├── search_trace.md
└── 00_Reference_Summary_Word/
    └── <topic>_Reference_Summary_with_IF_JCR_v0.1.docx
```

Word 表格字段：

```text
类别 | 文献名 | 期刊/来源 | 年份 | 影响因子/JCR | DOI/PMID/链接 | 对本课题的参考部分
```

## 安装

把本仓库复制到 Codex skills 目录：

```bash
mkdir -p ~/.codex/skills
git clone https://github.com/<your-user>/topic-reference-literature-skill.git ~/.codex/skills/topic-reference-literature
```

如果你下载的是 ZIP：

```bash
mkdir -p ~/.codex/skills/topic-reference-literature
unzip topic-reference-literature-skill-main.zip -d /tmp/topic-reference-literature-skill
cp -R /tmp/topic-reference-literature-skill/topic-reference-literature-skill-main/. ~/.codex/skills/topic-reference-literature/
```

## 使用示例

```text
调用文献-参考文献 skill，我想做一篇 ROCK 抑制剂载药角膜绷带镜治疗角膜上皮/内皮失代偿的课题，请帮我查文献并生成 Word 汇总表。
```

或者：

```text
我有这些 DOI/PMID，请用参考文献 skill 逐篇核对，补 IF/JCR，分类总结并生成 Word 表格。
```

## 质量规则

- Topic-first 模式必须真实检索，不能凭记忆编表。
- 默认至少 20 篇文献，除非用户明确要求更少。
- 每篇期刊文献必须有 DOI、PMID、PMCID 或官方链接之一。
- 每篇期刊文献必须有 JCR 年份、影响因子和 JCR 分区。
- `待核实` 只能用于少数确实无法公开确认的期刊，并必须写明原因。
- 非期刊来源标注为 `非期刊; 无 JCR/IF`。

## 依赖

生成 Word 文件需要 Python 和 `python-docx`。Codex Desktop 的 bundled runtime 通常已经包含所需依赖；普通 Python 环境可安装：

```bash
python3 -m pip install python-docx
```

## 文件结构

```text
topic-reference-literature/
├── SKILL.md
├── agents/
│   └── openai.yaml
└── scripts/
    └── build_reference_summary_docx.py
```

## License

MIT
