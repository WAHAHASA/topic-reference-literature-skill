from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


def safe_name(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", value.strip())
    return re.sub(r"_+", "_", value).strip("_") or "reference_summary"


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_cell_text(cell, text: str, bold: bool = False, size: int = 7) -> None:
    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_after = Pt(0)
    run = p.add_run(str(text or ""))
    run.font.name = "Arial"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    run.font.size = Pt(size)
    run.bold = bold
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


def set_table_borders(table) -> None:
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = f"w:{edge}"
        element = borders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "4")
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), "D9E2DD")


def add_note(doc: Document, text: str) -> None:
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.font.name = "Arial"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    r.font.size = Pt(9)
    r.font.color.rgb = RGBColor(90, 102, 99)
    p.paragraph_format.space_after = Pt(4)


def find_literature_dir(topic_root: Path) -> Path:
    candidates = [
        topic_root / "01_Literature",
        topic_root / "01_literature",
        topic_root / "Literature",
        topic_root / "参考文献",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return topic_root / "01_Literature"


def build_docx(topic_root: Path, manifest_path: Path, output_name: str | None) -> Path:
    refs = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(refs, list):
        raise ValueError("Manifest must be a JSON array.")
    if len(refs) < 20:
        raise ValueError(f"Expected at least 20 references, found {len(refs)}.")
    def has_no_jcr_listing(value: str) -> bool:
        return any(marker in value for marker in ("非期刊", "无当前 JCR", "无官方 JCR", "未收录 JCR", "未被 JCR 收录"))

    journal_refs = [
        ref for ref in refs if "非期刊" not in str(ref.get("impact_factor_jcr", ""))
    ]
    missing_metrics = [
        ref.get("title", "Untitled reference")
        for ref in journal_refs
        if (
            not ref.get("impact_factor_jcr")
            or (
                "待核实" not in str(ref.get("impact_factor_jcr", ""))
                and not has_no_jcr_listing(str(ref.get("impact_factor_jcr", "")))
                and (
                    "IF" not in str(ref.get("impact_factor_jcr", ""))
                    or "Q" not in str(ref.get("impact_factor_jcr", ""))
                )
            )
        )
    ]
    if missing_metrics:
        joined = "; ".join(missing_metrics[:5])
        raise ValueError(
            "Every journal article must include JCR year, Journal Impact Factor, and JCR quartile. "
            f"Missing or incomplete metrics for: {joined}"
        )
    pending_metrics = [
        ref for ref in journal_refs if "待核实" in str(ref.get("impact_factor_jcr", ""))
    ]
    if journal_refs and len(pending_metrics) / len(journal_refs) > 0.25:
        raise ValueError(
            "Too many journal rows still have pending IF/JCR metrics. "
            "Search and fill JCR year, IF, and quartile before generating the Word file."
        )

    literature_dir = find_literature_dir(topic_root)
    out_dir = literature_dir / "00_Reference_Summary_Word"
    out_dir.mkdir(parents=True, exist_ok=True)

    if not output_name:
        output_name = f"{safe_name(topic_root.name)}_Reference_Summary_with_IF_JCR_v0.1.docx"
    if not output_name.endswith(".docx"):
        output_name += ".docx"
    output_path = out_dir / output_name

    doc = Document()
    section = doc.sections[0]
    section.orientation = WD_ORIENT.LANDSCAPE
    section.page_width = Cm(29.7)
    section.page_height = Cm(21.0)
    section.top_margin = Cm(1.1)
    section.bottom_margin = Cm(1.1)
    section.left_margin = Cm(1.0)
    section.right_margin = Cm(1.0)

    normal = doc.styles["Normal"]
    normal.font.name = "Arial"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.font.size = Pt(9)

    title = doc.add_paragraph()
    run = title.add_run(f"{topic_root.name}：参考文献汇总表")
    run.bold = True
    run.font.name = "Arial"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    run.font.size = Pt(20)
    run.font.color.rgb = RGBColor(22, 32, 31)
    title.paragraph_format.space_after = Pt(6)

    add_note(doc, f"整理范围：本课题核心参考文献，共 {len(refs)} 篇/项。")
    add_note(doc, "影响因子说明：影响因子和 JCR 分区为期刊级指标；投稿前建议用 Web of Science JCR 再核对。无法确认者标注为待核实。")

    headers = ["类别", "文献名", "期刊/来源", "年份", "影响因子/JCR", "DOI/PMID/链接", "对本课题的参考部分"]
    keys = ["category", "title", "journal", "year", "impact_factor_jcr", "link", "role"]
    widths = [Cm(3.0), Cm(6.0), Cm(4.2), Cm(1.5), Cm(3.4), Cm(5.0), Cm(5.8)]

    table = doc.add_table(rows=1, cols=len(headers))
    table.autofit = False
    set_table_borders(table)
    for i, cell in enumerate(table.rows[0].cells):
        cell.width = widths[i]
        set_cell_shading(cell, "EAF3EE")
        set_cell_text(cell, headers[i], bold=True, size=8)

    for ref in refs:
        row = table.add_row()
        for i, key in enumerate(keys):
            cell = row.cells[i]
            cell.width = widths[i]
            set_cell_text(cell, ref.get(key, ""), size=7)

    doc.save(output_path)
    return output_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a Word reference summary table with IF/JCR metadata.")
    parser.add_argument("--topic-root", required=True, help="Path to topic/project root directory.")
    parser.add_argument("--manifest", required=True, help="JSON array with reference metadata.")
    parser.add_argument("--output-name", default=None, help="Output DOCX file name.")
    args = parser.parse_args()
    output = build_docx(Path(args.topic_root).resolve(), Path(args.manifest).resolve(), args.output_name)
    print(output)


if __name__ == "__main__":
    main()
