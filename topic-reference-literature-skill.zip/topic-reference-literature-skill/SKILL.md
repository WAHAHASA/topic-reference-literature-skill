---
name: topic-reference-literature
description: Build a high-quality reference-literature package for a new or existing scientific research topic, or summarize literature provided by the user. Use when the user proposes a topic and asks to 查文献/找参考文献/整理参考文献/生成参考文献文件夹, or when the user sends their own papers/DOIs/PMIDs/PDFs/reference list and asks Codex to summarize, classify, verify, add mandatory JCR year, Journal Impact Factor, and JCR quartile metrics, and generate a project-ready Word literature table. For topic-first tasks, the skill requires real search, IF/JCR verification, and at least 20 high-quality references by default. For user-provided literature, use the supplied papers as the source set, verify and supplement metadata, then generate the Word summary.
---

# Topic Reference Literature

## Non-Negotiable Rule

This skill has two valid modes:

1. **Topic-first search mode**: the user gives a topic. Perform real literature search, verify metadata, then create the Word file.
2. **User-provided literature mode**: the user sends papers, titles, DOIs, PMIDs, PDFs, screenshots, exported RIS/BibTeX/EndNote text, or a reference list. Use the provided literature as the source set, verify and complete metadata, then summarize and create the Word file.

Do not generate a reference table from memory. Do not fill a manifest with plausible-looking papers.

Journal Impact Factor and JCR quartile are mandatory deliverables, not optional decoration. Before generating the Word file, actively search journal metrics for every journal article and fill the newest reliable JCR year, Journal Impact Factor, and JCR quartile available.

In topic-first mode, always perform real search before Word generation. If network/search access is unavailable, stop and state that real literature search cannot be completed in this turn.

In user-provided literature mode, do not replace the user's list with a new search unless they ask. Verify the provided items, deduplicate them, complete missing DOI/PMID/JCR/IF, and summarize their role in the topic. If fewer than 20 items are provided, summarize all provided items and optionally suggest what categories are missing.

## Output Contract

For every triggered task:

1. Identify or create the topic root directory.
2. Create a reference folder under the topic root:

```text
<topic-root>/01_Literature/00_Reference_Summary_Word/
```

If the topic uses another established folder name for literature, use that folder and create `00_Reference_Summary_Word/` inside it.

3. In topic-first mode, perform real search and select at least 20 high-quality references unless the user explicitly requests fewer.
4. In user-provided literature mode, process the user's provided set first. Do not enforce 20 unless the user asks to supplement to 20.
5. Prefer primary high-impact research articles, clinical guidelines/consensus reports, major reviews, translational studies, and method papers directly tied to the topic.
6. Generate a Word `.docx` table with at least these columns:

```text
类别 | 文献名 | 期刊/来源 | 年份 | 影响因子/JCR | DOI/PMID/链接 | 对本课题的参考部分
```

7. Include JCR year, Journal Impact Factor, and JCR quartile for every journal article. Use the newest reliable JCR data available.
8. Mark non-journal sources as `非期刊; 无 JCR/IF`.
9. Use `待核实` only for individual journals after a documented metrics search fails or returns conflicting data. Never leave the whole table or most journal articles as `待核实`.
10. Keep information shared within one project: use existing project context, prior reference files, prior strategy documents, and shared rules before starting from scratch.

## Mode Decision

Use **topic-first search mode** when:

- the user only gives a topic or hypothesis;
- the user asks "帮我查文献", "找不少于20篇", "生成参考文献文件夹";
- the user asks for a literature package without giving enough references.

Use **user-provided literature mode** when:

- the user says "这是我查的文献", "我发给你文献你总结", "根据这些 DOI/PMID/PDF";
- the user uploads PDFs, RIS/BibTeX/EndNote exports, or a reference list;
- the task is to summarize, classify, or convert the user's own literature into the project format.

## Literature Search Workflow

1. Parse the topic into:
   - disease/problem
   - material/device/intervention
   - mechanism
   - model/system
   - target application
   - likely article type

2. Execute real searches. Use multiple query groups, not a single broad query:
   - disease/problem terms
   - material/device/intervention terms
   - mechanism terms
   - model/evaluation terms
   - review/guideline terms

3. Search in tiers:
   - PubMed for biomedical and clinical evidence.
   - CrossRef and publisher pages for DOI, metadata, and citation accuracy.
   - High-impact journal and society reports for consensus/guideline references.
   - Official sources for labels, regulatory documents, trial snapshots, and product instructions.
   - Use web search for journal metrics. Prefer Clarivate JCR/Web of Science when available; otherwise use journal publisher metric pages, society journal pages, indexed journal pages, or reputable JCR summary pages. Record uncertainty when a source is not official.

4. Verify each candidate before inclusion:
   - full title
   - authors or first author et al.
   - journal/source
   - year
   - DOI, PMID, PMCID, or official URL
   - relevance to the topic
   - journal JCR year, IF, and quartile, plus the source type used to verify it

5. Build a balanced reference set:
   - 3-5 field-defining disease/problem references.
   - 4-6 mechanism or pathophysiology references.
   - 4-6 material/device/method references.
   - 3-5 therapeutic/intervention references.
   - 2-4 evaluation/model/statistical endpoint references.
   - Add more if needed so the final count is at least 20.

6. Deduplicate and quality-rank:
   - Prefer systematic reviews, guidelines, high-impact primary papers, recent translational work, and method papers that directly affect experimental design.
   - Remove papers that only mention the topic tangentially.
   - Keep older classics when they are necessary for device precedent, clinical precedent, or measurement parameters.

7. Use the newest reliable JCR data available. If exact JCR data cannot be verified during the turn for a specific journal, write a specific reason such as `JCR/IF 待核实：未找到公开 JCR/出版商指标页` or `JCR/IF 待核实：公开来源冲突`, and provide the DOI/source link. Do not use generic `JCR/IF 待核实` as a default.

8. For each reference, write the topic-specific role in plain Chinese. Do not use generic phrases like “background reference” unless the role is genuinely broad.

9. Save a search trace when useful:

```text
<topic-root>/01_Literature/search_trace.md
```

Include query groups, databases/sources searched, metrics sources searched, and selection logic. Keep it concise.

## Word Generation

Only after real search and verification, create a manifest JSON and use the bundled script:

```bash
python scripts/build_reference_summary_docx.py \
  --topic-root <topic-root> \
  --manifest <references.json> \
  --output-name <short-name>.docx
```

Manifest JSON format:

```json
[
  {
    "category": "A. 疾病背景",
    "title": "Full article title",
    "journal": "Journal name",
    "year": "2024",
    "impact_factor_jcr": "JCR 2024 IF 12.3; Q1",
    "link": "DOI/PMID/PMCID/official URL",
    "role": "这篇文献在本课题中的具体用途"
  }
]
```

For user-provided literature mode, add optional fields when useful:

```json
{
  "user_note": "用户提供的备注或原始分类",
  "summary": "一句话总结该文献核心发现",
  "evidence_level": "guideline/review/clinical/materials/method/mechanism/animal/in vitro"
}
```

If a user asks for the final document only, return only the `.docx` link and a short note. If useful, also mention the number of references included.

## Quality Rules

- Minimum reference count: 20.
- Real search is mandatory before Word generation in topic-first search mode.
- In user-provided literature mode, user-supplied references are the primary source set.
- Include fewer than 20 references only when the user explicitly requests a smaller set or the topic is too narrow after documented search attempts.
- Every journal article must have a journal/source and a DOI/PMID/link if available.
- Every reference must include its role in the topic.
- JCR year, Journal Impact Factor, and JCR quartile must be shown for every journal article whenever the journal has a current JCR listing.
- `待核实` is allowed only as a last resort for specific journals after an attempted metrics search; include the reason in the cell or search trace.
- Do not generate the final Word file if all, or most, journal rows still have `待核实` metrics.
- Prefer real source links over search-result links.
- Do not download paywalled PDFs unless the user provides access or explicitly requests use of their browser/session.
- For official labels, reports, and regulatory pages, use `非期刊; 无 JCR/IF`.
- For old discontinued journals, use `无当前 JCR IF` or `待核实`.

## Suggested File Names

Use:

```text
<topic-root>/01_Literature/00_Reference_Summary_Word/<topic-short-name>_Reference_Summary_with_IF_JCR_v0.1.docx
```

For Chinese project folders, use ASCII-safe English file names unless the user explicitly prefers Chinese names.
